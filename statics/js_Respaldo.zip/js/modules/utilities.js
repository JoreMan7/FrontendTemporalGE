// Funciones utilitarias
export function setupBackButton(selector) {
    const backButton = document.querySelector(selector);
    backButton?.addEventListener('click', () => window.history.back());
}

export function setCurrentDate(elementId, options = { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
}) {
    const element = document.getElementById(elementId);
    if (element) {
        element.textContent = new Date().toLocaleDateString('es-ES', options);
    }
}

// Función específica para el formato que necesitas
export function setSpanishLongDate(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        const now = new Date();
        const options = {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        };
        element.textContent = now.toLocaleDateString('es-ES', options);
    }
}

export function isMobile() {
    return window.innerWidth <= 768;
}

export function showToast(message, type = 'default') {
    // Crear o reutilizar elemento toast si es necesario
    let toast = document.getElementById('toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'toast';
        toast.className = 'toast';
        document.body.appendChild(toast);
    }
    
    toast.textContent = message;
    toast.className = 'toast show';
    
    if (type === 'success') {
        toast.classList.add('success');
    } else if (type === 'error') {
        toast.classList.add('error');
    }
    
    setTimeout(() => {
        toast.className = 'toast';
    }, 3000);
}

/**
 * Establece dinámicamente el título de la página usando el <title> del documento.
 * Si el título tiene formato "Sección - GESTIÓN ECLESIAL", solo muestra la primera parte.
 */
export function setDynamicPageTitle() {
  const titleElement = document.getElementById("pageTitle");
  if (!titleElement) return;

  // Obtiene el <title> del documento
  let titulo = document.title || "";

  // Si tiene un separador " - ", solo usa la primera parte
  if (titulo.includes(" - ")) {
    titulo = titulo.split(" - ")[0];
  }

  // Convierte a mayúsculas sin tildes
  titulo = titulo
    .normalize("NFD")               // separa los acentos
    .replace(/[\u0300-\u036f]/g, "") // elimina los acentos
    .toUpperCase();

  // Asigna el texto al elemento visual
  titleElement.textContent = titulo;
}
